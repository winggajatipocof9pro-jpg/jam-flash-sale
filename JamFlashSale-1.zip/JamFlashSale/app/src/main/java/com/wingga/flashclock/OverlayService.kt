package com.wingga.flashclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.TimeZone

class OverlayService : Service() {

    companion object {
        const val EXTRA_TARGET = "target"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "flashclock"
        private const val DAY = 86_400_000L
    }

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var clockText: TextView
    private lateinit var countText: TextView
    private var targetMs = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 30)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        targetMs = (intent?.getIntExtra(EXTRA_TARGET, 0) ?: 0) * 1000L
        startInForeground()
        if (overlay == null) showOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jam Flash Sale", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jam Flash Sale aktif")
            .setContentText("Ketuk untuk menutup jam melayang")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(stopPi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    private fun showOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        clockText = TextView(this).apply {
            textSize = 20f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        countText = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(8), dp(20), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(28).toFloat()
            }
            addView(clockText)
            addView(countText)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(6)
        }

        // Geser dengan jari untuk memindahkan posisi jam.
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        pill.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(pill, lp)
                }
            }
            true
        }

        wm.addView(pill, lp)
        overlay = pill
    }

    private fun update() {
        val now = System.currentTimeMillis()
        val local = now + TimeZone.getDefault().getOffset(now)
        val msOfDay = ((local % DAY) + DAY) % DAY

        val h = (msOfDay / 3_600_000).toInt()
        val m = ((msOfDay / 60_000) % 60).toInt()
        val s = ((msOfDay / 1000) % 60).toInt()
        val ms = (msOfDay % 1000).toInt()
        clockText.text = String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, s, ms)

        var diff = targetMs - msOfDay
        if (diff < 0) diff += DAY

        // 60 detik setelah jam mulai: tampilkan tanda serbu.
        if (diff == 0L || diff > DAY - 60_000) {
            countText.text = "SERBU SEKARANG!"
            countText.setTextColor(Color.parseColor("#4CAF50"))
            return
        }

        countText.setTextColor(
            when {
                diff <= 10_000 -> Color.parseColor("#FF5252")
                diff <= 60_000 -> Color.parseColor("#FFC107")
                else -> Color.WHITE
            }
        )

        val dh = (diff / 3_600_000).toInt()
        val dm = ((diff / 60_000) % 60).toInt()
        val ds = ((diff / 1000) % 60).toInt()
        val dt = ((diff % 1000) / 100).toInt()
        countText.text = if (dh > 0) {
            String.format(Locale.US, "-%d:%02d:%02d", dh, dm, ds)
        } else {
            String.format(Locale.US, "-%02d:%02d.%d", dm, ds, dt)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        super.onDestroy()
    }
}
