package com.wingga.flashclock

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var input: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setOnApplyWindowInsetsListener { v, insets ->
                @Suppress("DEPRECATION")
                v.setPadding(
                    dp(24), dp(24) + insets.systemWindowInsetTop,
                    dp(24), dp(24) + insets.systemWindowInsetBottom
                )
                insets
            }
        }

        root.addView(TextView(this).apply {
            text = "Jam Flash Sale"
            textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Jam melayang di atas aplikasi Shopee, lengkap dengan milidetik dan hitung mundur."
            textSize = 14f
            setPadding(0, dp(8), 0, dp(24))
        })

        root.addView(TextView(this).apply { text = "Jam mulai flash sale (HH:MM:SS)" })
        input = EditText(this).apply {
            setText("12:00:00")
            inputType = InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_TIME
            textSize = 22f
        }
        root.addView(input)

        // Contoh jam; ubah sesuai jadwal flash sale yang kamu incar.
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("00:00:00", "12:00:00", "19:00:00").forEach { t ->
            presets.addView(Button(this).apply {
                text = t.substring(0, 5)
                setOnClickListener { input.setText(t) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(presets)

        root.addView(Button(this).apply {
            text = "MULAI JAM MELAYANG"
            setOnClickListener { start() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        root.addView(Button(this).apply {
            text = "BERHENTI"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })

        root.addView(TextView(this).apply {
            text = "Tips: aktifkan waktu otomatis (jaringan) di Pengaturan agar jam akurat. " +
                "Di HyperOS, izinkan juga \"Tampilkan di atas aplikasi lain\" dan atur Hemat Baterai ke \"Tanpa batasan\"."
            textSize = 12f
            gravity = Gravity.START
            setPadding(0, dp(24), 0, 0)
        })

        setContentView(root)
    }

    private fun parseSeconds(s: String): Int? {
        val p = s.trim().split(":").mapNotNull { it.toIntOrNull() }
        if (p.size !in 2..3) return null
        val h = p[0]; val m = p[1]; val sec = p.getOrElse(2) { 0 }
        if (h !in 0..23 || m !in 0..59 || sec !in 0..59) return null
        return h * 3600 + m * 60 + sec
    }

    private fun start() {
        val target = parseSeconds(input.text.toString())
        if (target == null) {
            Toast.makeText(this, "Format jam salah. Contoh: 12:00:00", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan \"Tampilkan di atas aplikasi lain\", lalu tekan Mulai lagi", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(
            Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_TARGET, target)
        )
        Toast.makeText(this, "Jam aktif. Buka Shopee sekarang.", Toast.LENGTH_SHORT).show()
    }
}
